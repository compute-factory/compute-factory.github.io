"""Measure a local SmolLM2 model on CPU. Run from this script's directory."""

import argparse
import json
import platform
from pathlib import Path
from time import perf_counter

import psutil
import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.utils import logging as hf_logging


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, default=Path("weights"))
    parser.add_argument("--json", type=Path, help="Also save the measurements as JSON")
    args = parser.parse_args()
    hf_logging.disable_progress_bar()
    torch.set_num_threads(4)
    process = psutil.Process()
    mib = 1024**2

    # Prepare the exact same prompt before measuring the model load.
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    prompt = "What is the capital of France?"
    inputs = tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}],
        add_generation_prompt=True, return_tensors="pt", return_dict=True,
    )
    before = process.memory_info().rss
    start = perf_counter()
    model = AutoModelForCausalLM.from_pretrained(
        args.model, dtype=torch.float32, local_files_only=True,
    )
    load_seconds = perf_counter() - start
    loaded = process.memory_info().rss
    model.eval()

    with torch.inference_mode():
        output = model.generate(**inputs, max_new_tokens=16, do_sample=False)
    generated = process.memory_info().rss

    new_ids = output[0, inputs["input_ids"].shape[1]:]
    answer = tokenizer.decode(new_ids, skip_special_tokens=True)
    parameters = sum(p.numel() for p in model.parameters())
    weight_bytes = sum(p.numel() * p.element_size() for p in model.parameters())
    assert all(p.device.type == "cpu" and p.dtype == torch.float32 for p in model.parameters())
    assert parameters * 4 == weight_bytes and new_ids.numel() > 0

    print(f"SmolLM2-135M-Instruct | CPU | FP32 | {torch.get_num_threads()} threads")
    print(f"Parameters: {parameters:,}   FP32 parameter tensors: {weight_bytes / mib:.2f} MiB")
    print(f"Model load: {load_seconds:.3f} s (local files)")
    print()
    print("Process RSS               MiB")
    for stage, value in [("Before model load", before), ("After model load", loaded),
                         ("After generation", generated)]:
        print(f"  {stage:<21} {value / mib:8.2f}")
    print()
    print(f"Prompt: {prompt}")
    print(f"Reply ({new_ids.numel()} new tokens, including any EOS): {answer.strip()}")

    if args.json:
        report = {
            "python": platform.python_version(), "os": platform.platform(),
            "torch": torch.__version__, "transformers": transformers.__version__,
            "psutil": psutil.__version__, "cpu_threads": torch.get_num_threads(),
            "model_type": model.config.model_type, "device": "cpu", "dtype": "float32",
            "parameters": parameters, "parameter_bytes": weight_bytes,
            "load_seconds": load_seconds,
            "rss_bytes": {"before_load": before, "after_load": loaded, "after_generate": generated},
            "input_tokens": inputs["input_ids"].shape[1], "new_tokens": new_ids.numel(),
            "prompt": prompt, "reply": answer,
        }
        args.json.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
