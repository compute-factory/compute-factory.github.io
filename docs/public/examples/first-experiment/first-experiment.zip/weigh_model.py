from pathlib import Path

import torch
from transformers import AutoModelForCausalLM
from transformers.utils import logging

logging.disable_progress_bar()
torch.set_num_threads(4)
weights = Path("weights")
for dtype in (torch.bfloat16, torch.float32):
    model = AutoModelForCausalLM.from_pretrained(
        weights, dtype=dtype, local_files_only=True,
    )
    embedding = model.get_input_embeddings().weight
    count = sum(p.numel() for p in model.parameters())
    size = sum(p.numel() * p.element_size() for p in model.parameters())
    print(embedding.dtype, tuple(embedding.shape), count, f"{size / 1024**2:.2f} MiB")
    del embedding, model
